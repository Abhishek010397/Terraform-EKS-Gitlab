import json
import boto3
import uuid

client = boto3.client('stepfunctions')

def lambda_handler(event,context):
    #INPUT -> { (unique)"TransactionID": "foo", "Type":"PURCHASE"}
    transactionId = str(uuid.uuid1()) #random string of characters with dashes as it returns an object we make it string
    
    input = {'TranactionId' : transactionId, 'Type' :  'PURCHASE' }
    
    response = client.start_execution(
        stateMachineArn = 'arn:aws:states:us-east-1:680763698946:stateMachine:testECStask' ,
        name = transactionId,
        input = json.dumps(input)
    )
    